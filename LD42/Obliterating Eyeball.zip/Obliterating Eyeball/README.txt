Possible Error Fixes:

If you receive an error similar to "Code execution can't proceed because OpenAL32.dll wasn't found".
  -Go to the installation directory of the game, go into the 'OpenAL' folder, and run oalinst.exe
